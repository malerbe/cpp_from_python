#include <petriNetwork.hpp>

petri::Network::Network(unsigned int seed)
  : gen(seed) {
}
