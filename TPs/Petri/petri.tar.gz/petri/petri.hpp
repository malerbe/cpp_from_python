#pragma once

// Here, we include all the petri-related definitions.

#include <petriPool.hpp>
#include <petriTransition.hpp>
#include <petriNetwork.hpp>


