#include <petriTransition.hpp>

// To be done
